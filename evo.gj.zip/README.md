# fortnite-external-evo.gj
an open source fortnite external cheat hack what ever u want to call it called evo.gj bc evo.gg use to be the best paste ever so im going to remake it!!!

Updated to Version v.29.10

add me on discord to ask for new features.

Drag the driver.sys into the kdmapper to map the driver for your base id to not be 0

my discord: droused
